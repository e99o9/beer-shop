
import React from 'react'

export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', textAlign: 'center', padding: 20 }}>
      <h1>Пивная Лавка</h1>
      <p>Сайт в разработке. QR-код Kaspi доступен в полной версии.</p>
      <img src="/kaspi-qr.png" alt="Kaspi QR" style={{ width: 200 }} />
    </div>
  )
}
